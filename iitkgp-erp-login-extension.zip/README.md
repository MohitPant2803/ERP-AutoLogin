# 🚀 IIT KGP ERP 1-Click Login - Chrome Extension

An ultra-fast, modern Chrome extension for IIT Kharagpur students that automates the entire ERP login workflow in **a single click** — eliminating manual credential typing, security question lookup, and OTP hassle.

Built with direct architectural parity to [`metakgp/iitkgp-erp-login-pypi`](https://github.com/metakgp/iitkgp-erp-login-pypi).

---

## ✨ Features

- **🚀 1-Click Headless Login**: Click once from the Chrome toolbar or press `Alt + Shift + L` to immediately log into IIT KGP ERP.
- **🔄 Auto-Fetch Security Questions**: Automatically queries ERP to discover all 3 of your registered security questions in seconds so you only have to provide the answers once.
- **📬 Multi-Channel Automated OTP Resolution**:
  1. **Open Webmail Tab Scanner (Recommended - Zero Setup!)**: Silently captures the 6-digit ERP OTP if you have Gmail (`mail.google.com`) or Zimbra Webmail (`iitkgpmail.iitkgp.ac.in`) open in any tab.
  2. **Clipboard Auto-Detect**: If you copy the 6-digit OTP code on your phone, laptop notification, or email preview, the extension instantly detects, pastes, and submits it.
  3. **Direct Gmail API**: Matches `read_mail.py` from `iitkgp-erp-login-pypi` using Google OAuth / API access token.
  4. **Local Python Companion Helper**: Connects to `http://127.0.0.1:5000/otp` if you run the local helper script with `credentials.json` / `token.json`.
  5. **Instant In-Page Floating Bar**: A sleek overlay with auto-focused OTP input and instant submit as soon as 6 digits are typed or pasted.
- **🧹 Automatic Session Conflict Recovery**: Handles ERP's infamous `"previous session is still active"` error automatically by invoking `clearAllSessions.htm` and retrying seamlessly.
- **🔒 Local & Secure**: Credentials never leave your browser profile. Optional 4-digit PIN protection with AES-GCM 256-bit encryption.
- **🌐 In-Page & Background Support**: Works both headlessly from the extension popup/shortcut and in-page when you navigate to `https://erp.iitkgp.ac.in/`.

---

## 📦 How to Install in Chrome ("Drop in Chrome Package")

You can load this extension into any Chromium browser (Google Chrome, Brave, Edge, Arc, etc.) in under 30 seconds:

1. **Open Extensions Page**:
   - In Google Chrome, go to `chrome://extensions` in your address bar.
2. **Enable Developer Mode**:
   - Toggle the **"Developer mode"** switch located in the top-right corner.
3. **Load the Extension**:
   - Click the **"Load unpacked"** button in the top-left.
   - Select the `extension` folder (or this root project folder: `c:\Users\Mohit\Desktop\Devlopment\erpLogin\extension`).
   - *Alternatively, you can extract `iitkgp-erp-login-extension.zip` and select that folder.*
4. **Pin to Toolbar**:
   - Click the puzzle icon 🧩 in Chrome's top-right toolbar and pin **"ERP 1-Click Login"**.

---

## ⚙️ Initial Configuration (1-Minute Setup)

1. Click the **ERP 1-Click Login** extension icon in your toolbar.
2. Enter your **Roll Number** (e.g. `21CS10001`).
3. Click **"🔄 Fetch Qs"**:
   - The extension automatically polls ERP to retrieve all 3 of your registered security questions!
4. Enter your **ERP Password** and the answers to your 3 questions.
5. Click **"💾 Save Credentials"**.

*You are all set!*

---

## 🎯 How to Use

### Option 1: Toolbar 1-Click
1. Click the extension icon.
2. Hit **"🚀 1-Click Login to ERP"**.
3. The extension checks existing sessions, gets session tokens, answers the challenge question, captures the OTP, and launches your authenticated ERP dashboard!

### Option 2: Keyboard Shortcut
- Press **`Alt + Shift + L`** anywhere in Chrome to trigger immediate login.

### Option 3: Direct Web Navigation
- Simply open [erp.iitkgp.ac.in](https://erp.iitkgp.ac.in/IIT_ERP3/).
- The extension automatically prefills credentials, requests OTP, listens for the code, and logs you in.

---

## 🛠️ Automated OTP Resolution Modes

| Mode | How it Works | Setup Needed |
| :--- | :--- | :--- |
| **Webmail Tab Auto-Scan** *(Default)* | Reads OTP from an open Gmail (`mail.google.com`) or Zimbra (`iitkgpmail.iitkgp.ac.in`) tab. | Just keep your email open in any tab! |
| **Clipboard Auto-Detect** | Detects when a 6-digit OTP is copied to your clipboard and auto-submits. | Just copy the OTP! |
| **Direct Gmail API** | Background worker polls Google Gmail API directly for the ERP email. | Add OAuth token in Settings. |
| **Local Python Helper** | Polls `http://127.0.0.1:5000/otp` using the companion python script. | Run `python python-otp-helper/otp_server.py`. |

### Running the Python Companion Helper (Optional)
If you already use `iitkgp-erp-login-pypi` with `credentials.json` and `token.json`:
```bash
cd python-otp-helper
pip install -r requirements.txt
python otp_server.py
```
Then enable "Local Python OTP Helper Server" in the extension's Settings page (`options.html`).

---

## 📂 Project Structure

```
erpLogin/
├── manifest.json              # Chrome Manifest V3 configuration
├── background.js              # Background service worker (login state & OTP listener)
├── erp-api.js                 # Complete IIT KGP ERP API client & session manager
├── crypto-util.js             # Web Crypto AES-GCM 256-bit encryption for PIN security
├── content.js                 # In-page autofill & floating overlay for erp.iitkgp.ac.in
├── content.css                # In-page overlay styles
├── mail-reader.js             # Content script on Gmail & Zimbra tabs to capture OTPs
├── popup.html / .css / .js    # Toolbar popup interface
├── options.html / .css / .js  # Full settings, diagnostics & backup page
├── icons/                     # Extension icons (16, 48, 128px)
├── extension/                 # Clean, standalone ready-to-load extension directory
├── iitkgp-erp-login-extension.zip # Pre-packaged ZIP for one-click loading
└── python-otp-helper/         # Local companion server (Gmail API parity)
```

---

## 🛡️ Privacy & Security

- **No external telemetry**: All credentials and question answers are stored solely inside your local Chrome profile via `chrome.storage.local`.
- **Optional PIN Encryption**: If enabled, credentials are encrypted with AES-GCM using PBKDF2 key derivation and only decrypted in-memory when you provide your PIN.
- **Session Auto-Clear**: Automatically clears ghost sessions when ERP blocks you with `"previous session is still active"`.
