/**
 * Content Script for IIT KGP ERP Portal (erp.iitkgp.ac.in).
 * Handles in-page autofill, security question matching, OTP auto-detection, and auto-submission.
 */

(() => {
  // Check if we are on the login page or a page containing the login form
  const isLoginPage = () => {
    return (
      window.location.href.includes('SSOAdministration/login.htm') ||
      window.location.href.includes('IIT_ERP3') ||
      document.getElementById('user_id') !== null ||
      document.getElementById('loginForm') !== null
    );
  };

  if (!isLoginPage()) {
    return;
  }

  let cardElem = null;
  let statusTextElem = null;
  let spinnerElem = null;
  let otpSectionElem = null;
  let manualSectionElem = null;
  let otpInputElem = null;
  let countdownTimer = null;
  let isSubmitting = false;
  let currentCreds = null;

  // Global listener: flags when user clicks any logout link anywhere on ERP
  document.addEventListener('click', (e) => {
    const target = e.target.closest('a, button, input[type="button"], span');
    if (target) {
      const href = (target.getAttribute('href') || '').toLowerCase();
      const text = (target.innerText || '').toLowerCase();
      const onclick = (target.getAttribute('onclick') || '').toLowerCase();
      if (
        href.includes('logout') ||
        text.includes('logout') ||
        text.includes('log out') ||
        text.includes('sign out') ||
        onclick.includes('logout')
      ) {
        console.log('[ERP Content] User clicked logout. Clearing session state...');
        sessionStorage.clear();
        chrome.storage.local.remove(['erp_latest_otp', 'erp_active_login']);
      }
    }
  }, true);

  /**
   * Attaches input, change, and paste listeners to ERP page OTP inputs
   */
  function attachPageOtpListener() {
    const pageOtpInputs = document.querySelectorAll('#email_otp1, input[name="email_otp"], input[id*="email_otp"]');
    pageOtpInputs.forEach((input) => {
      ['input', 'change', 'paste'].forEach((evtType) => {
        input.addEventListener(evtType, (e) => {
          setTimeout(() => {
            const val = (e.target.value || '').replace(/\D/g, '');
            if (val.length === 6 && val !== '721302') {
              handleOtpFound(val);
            }
          }, 30);
        });
      });
    });
  }

  /**
   * Checks if the user reached this page via a logout action
   */
  const isLogoutPage = () => {
    const search = window.location.search.toLowerCase();
    const href = window.location.href.toLowerCase();
    const justLoggedOut = sessionStorage.getItem('erp_just_logged_out') === 'true';
    return (
      search.includes('logout') ||
      href.includes('logout') ||
      justLoggedOut
    );
  };

  chrome.storage.local.get(['authCredentials', 'otpSettings', 'autoLogin'], async (res) => {
    const creds = res.authCredentials;
    if (!creds || !creds.rollNumber || !creds.password) {
      console.log('ERP 1-Click Login: Credentials not configured yet.');
      return;
    }

    currentCreds = creds;
    const isAutoLoginEnabled = (res.autoLogin !== undefined) ? res.autoLogin : (creds.autoLogin !== false);

    // Wait until DOM is fully interactive
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => init(creds, isAutoLoginEnabled));
    } else {
      init(creds, isAutoLoginEnabled);
    }
  });

  function init(creds, isAutoLoginEnabled) {
    // If landed on logout page, immediately redirect to login page so login cycle continues
    if (window.location.href.includes('logout.htm') || window.location.pathname.includes('logout')) {
      console.log('[ERP Content] On logout page. Navigating back to login page...');
      setTimeout(() => {
        window.location.href = window.location.origin + '/IIT_ERP3/';
      }, 500);
      return;
    }

    const userIdInput = document.getElementById('user_id');
    if (!userIdInput) {
      return;
    }

    // Strip any eye toggle buttons or password reveal mechanisms on ERP
    const stripEyeButtons = () => {
      document.querySelectorAll('.toggle-password, .show-password, [id*="toggle-pwd"], [id*="togglePassword"], .fa-eye, .fa-eye-slash').forEach((el) => {
        try { el.remove(); } catch {}
      });
      const pwd = document.getElementById('password');
      if (pwd) {
        pwd.type = 'password';
        pwd.setAttribute('type', 'password');
      }
    };
    stripEyeButtons();
    setTimeout(stripEyeButtons, 500);
    setTimeout(stripEyeButtons, 1500);

    renderCard(creds.rollNumber, creds);

    // 0. Save sessionToken to sessionStorage whenever present in URL
    const urlToken = new URLSearchParams(window.location.search).get('sessionToken');
    if (urlToken) {
      sessionStorage.setItem('erp_session_token', urlToken);
    }

    // 1. If General Behavior "Auto-Login on Page Visit" is disabled (turned off)
    if (!isAutoLoginEnabled) {
      console.log('ERP 1-Click Login: Auto-login is disabled in General Behavior settings.');
      updateStatus('Auto-login disabled in General Behavior.', false, false);
      showManualLoginButton();
      return;
    }

    // 3. Check if the page contains an active session error from a previous attempt
    const bodyText = document.body ? document.body.innerText.toLowerCase() : '';
    if (bodyText.includes('previous session is still active') || bodyText.includes('session is active')) {
      console.log('[ERP Content] Active session detected on page load. Auto-clearing sessions...');
      updateStatus('Previous session was active! Auto-clearing sessions...', false);
      ErpApi.clearAllSessions(creds.rollNumber).then(() => {
        updateStatus('Sessions cleared! Re-starting clean login...', false);
        sessionStorage.removeItem('erp_otp_requested_time');
        setTimeout(() => {
          window.location.href = window.location.origin + '/IIT_ERP3/';
        }, 600);
      });
      return;
    }

    // 4. Check if we landed on auth.htm (indicates previous submission was rejected by ERP)
    if (window.location.pathname.includes('auth.htm')) {
      console.warn('[ERP Content] Landed on auth.htm: Previous OTP or login rejected.');
      updateStatus('Previous OTP was invalid or expired. Please enter new OTP.', true, false);
      showManualLoginButton();
      if (otpSectionElem) otpSectionElem.style.display = 'block';
      return;
    }

    // 5. Check if the page already has an OTP mismatch error from previous submit
    if (bodyText.includes('otp mismatch') || bodyText.includes('invalid otp')) {
      updateStatus('Previous OTP mismatch. Click Resend OTP or enter code.', true, false);
      showManualLoginButton();
      if (otpSectionElem) otpSectionElem.style.display = 'block';
      return;
    }

    // 6. Normal auto-login flow
    startInPageLogin(creds);
  }

  function showManualLoginButton() {
    if (spinnerElem) spinnerElem.style.display = 'none';
    if (manualSectionElem) manualSectionElem.style.display = 'block';
  }

  /**
   * Renders the floating status and quick-control overlay
   */
  function renderCard(rollNumber, creds) {
    if (document.getElementById('erp-auto-login-card')) return;

    cardElem = document.createElement('div');
    cardElem.id = 'erp-auto-login-card';
    cardElem.innerHTML = `
      <div class="erp-card-header">
        <div class="erp-card-title">
          <svg class="icon-svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
          <span>ERP 1-Click Login</span>
        </div>
        <div class="erp-card-badge">${rollNumber}</div>
      </div>
      <div class="erp-status-box">
        <div class="erp-spinner" id="erp-spinner"></div>
        <div class="erp-status-text" id="erp-status-text">
          Initializing 1-Click Login...
        </div>
      </div>
      <div class="erp-manual-section" id="erp-manual-section" style="display: none; margin-bottom: 12px;">
        <button type="button" class="erp-btn erp-btn-primary" style="width: 100%; font-size: 13.5px; padding: 11px; font-weight: 700; box-shadow: 0 4px 14px rgba(2, 132, 199, 0.4);" id="erp-manual-login-btn">
          <svg class="icon-svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
          <span>1-Click Login to ERP</span>
        </button>
      </div>
      <div class="erp-otp-section" id="erp-otp-section" style="width: 100%; box-sizing: border-box;">
        <div style="font-size: 12px; color: #94a3b8; margin-bottom: 6px;">
          OTP requested. Fetching from Gmail API...
        </div>
        <div class="erp-otp-input-group" style="display: flex; gap: 8px; width: 100%; box-sizing: border-box; align-items: stretch; margin-bottom: 10px;">
          <input type="password" class="erp-otp-field" id="erp-overlay-otp" maxlength="6" placeholder="••••••" autocomplete="one-time-code" style="flex: 1 1 0%; min-width: 0; width: 0; box-sizing: border-box;" />
          <button type="button" class="erp-btn erp-btn-secondary" id="erp-paste-btn" style="flex: 0 0 auto; flex-shrink: 0; white-space: nowrap; box-sizing: border-box;">
            <svg class="icon-svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg>
            <span>Paste</span>
          </button>
        </div>
        <button type="button" class="erp-btn erp-btn-primary" style="width: 100%; box-sizing: border-box;" id="erp-submit-otp-btn">
          <svg class="icon-svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          <span>Instant Submit (<span id="erp-countdown">60</span>s)</span>
        </button>
      </div>
      <div class="erp-actions-row">
        <span>Press <strong>Alt+Shift+L</strong> anytime</span>
        <button type="button" class="erp-link-btn" id="erp-clear-sessions-btn">Clear Sessions</button>
      </div>
    `;

    document.body.appendChild(cardElem);

    statusTextElem = document.getElementById('erp-status-text');
    spinnerElem = document.getElementById('erp-spinner');
    otpSectionElem = document.getElementById('erp-otp-section');
    manualSectionElem = document.getElementById('erp-manual-section');
    otpInputElem = document.getElementById('erp-overlay-otp');

    // Manual login button handler (used when auto-login is disabled or after logout)
    const manualBtn = document.getElementById('erp-manual-login-btn');
    if (manualBtn) {
      manualBtn.addEventListener('click', () => {
        sessionStorage.removeItem('erp_just_logged_out');
        if (manualSectionElem) manualSectionElem.style.display = 'none';
        if (spinnerElem) spinnerElem.style.display = 'block';
        startInPageLogin(creds || currentCreds);
      });
    }

    // Paste button handler
    const pasteBtn = document.getElementById('erp-paste-btn');
    if (pasteBtn) {
      pasteBtn.addEventListener('click', async () => {
        try {
          const text = await navigator.clipboard.readText();
          const match = text.match(/\b\d{6}\b/);
          if (match && match[0] !== '721302') {
            handleOtpFound(match[0]);
          } else {
            updateStatus('No valid 6-digit OTP found in clipboard');
          }
        } catch {
          updateStatus('Clipboard access denied');
        }
      });
    }

    // Submit button handler
    const submitBtn = document.getElementById('erp-submit-otp-btn');
    if (submitBtn) {
      submitBtn.addEventListener('click', () => {
        if (otpInputElem && otpInputElem.value.trim().length === 6) {
          handleOtpFound(otpInputElem.value.trim());
        }
      });
    }

    // Auto-submit as soon as 6 digits are typed into overlay input
    if (otpInputElem) {
      otpInputElem.addEventListener('input', (e) => {
        const val = e.target.value.replace(/\D/g, '');
        e.target.value = val;
        if (val.length === 6) {
          handleOtpFound(val);
        }
      });
    }

    // Direct listener on native ERP page OTP input as well
    attachPageOtpListener();

    // Clear sessions link
    const clearBtn = document.getElementById('erp-clear-sessions-btn');
    if (clearBtn) {
      clearBtn.addEventListener('click', async () => {
        updateStatus('Clearing all active sessions...');
        await ErpApi.clearAllSessions(rollNumber);
        updateStatus('Active sessions cleared! Refreshing...');
        setTimeout(() => window.location.reload(), 1000);
      });
    }
  }

  function updateStatus(msg, isError = false, isSuccess = false) {
    if (statusTextElem) {
      statusTextElem.innerHTML = msg;
    }
    if (cardElem) {
      cardElem.classList.remove('erp-card-error', 'erp-card-success');
      if (isError) cardElem.classList.add('erp-card-error');
      if (isSuccess) cardElem.classList.add('erp-card-success');
    }
    if (spinnerElem) {
      spinnerElem.style.display = (isError || isSuccess) ? 'none' : 'block';
    }
  }

  /**
   * Main login orchestration on the live ERP DOM
   */
  async function startInPageLogin(creds) {
    try {
      // 0. Reset all stale state from previous sessions
      isSubmitting = false;
      sessionStorage.removeItem('erp_otp_requested_time');
      sessionStorage.removeItem('erp_just_logged_out');
      await chrome.storage.local.remove(['erp_latest_otp', 'erp_active_login']);

      // Reset DOM OTP fields so no old OTP remains
      if (otpInputElem) otpInputElem.value = '';
      const existingOtpInputs = document.querySelectorAll('#email_otp1, input[name="email_otp"], input[id*="email_otp"]');
      existingOtpInputs.forEach((el) => {
        el.value = '';
        el.setAttribute('value', '');
      });

      updateStatus('Checking active sessions...');
      await ErpApi.clearAllSessions(creds.rollNumber);
      await new Promise(r => setTimeout(r, 200));

      updateStatus('Filling Roll Number...');

      let password = creds.password;
      let qaPairs = creds.qaPairs || [];

      // Handle PIN if required
      if (creds.requirePin) {
        updateStatus('PIN required to decrypt credentials...');
        const pin = prompt('Enter your 4-digit PIN for ERP Auto-Login:');
        if (!pin) {
          updateStatus('Login cancelled: PIN not provided', true);
          return;
        }
        password = await CryptoUtil.decrypt(creds.password, pin);
        qaPairs = await Promise.all(
          qaPairs.map(async (pair) => ({
            question: pair.question,
            answer: await CryptoUtil.decrypt(pair.answer, pin)
          }))
        );
      }

      const userIdInput = document.getElementById('user_id');
      const passwordInput = document.getElementById('password');
      const answerInput = document.getElementById('answer');

      if (!userIdInput) {
        updateStatus('Could not find user_id input on page', true);
        return;
      }

      // 1. Enter roll number
      userIdInput.value = creds.rollNumber;
      userIdInput.dispatchEvent(new Event('input', { bubbles: true }));
      userIdInput.dispatchEvent(new Event('change', { bubbles: true }));

      // 2. Trigger ERP's native blur to fetch security question
      updateStatus('Fetching security question...');
      userIdInput.focus();
      userIdInput.blur();

      // 3. Wait for ERP to populate #question label or fetch via API fallback
      const questionText = await waitForSecurityQuestion(creds.rollNumber);
      updateStatus(`Question: "${questionText.substring(0, 30)}..."`);

      // 4. Match answer
      const answer = ErpApi.matchAnswer(questionText, qaPairs);
      if (!answer) {
        throw new Error(`No saved answer matching: "${questionText}". Please update settings.`);
      }

      // 5. Fill Password (ensure type remains password)
      if (passwordInput) {
        passwordInput.type = 'password';
        passwordInput.value = password;
        passwordInput.dispatchEvent(new Event('input', { bubbles: true }));
        passwordInput.dispatchEvent(new Event('change', { bubbles: true }));
      }

      // 6. Fill Answer
      if (answerInput) {
        answerInput.readOnly = false;
        answerInput.removeAttribute('readonly');
        answerInput.value = answer;
        answerInput.dispatchEvent(new Event('input', { bubbles: true }));
        answerInput.dispatchEvent(new Event('change', { bubbles: true }));
      }

      // Populate sessionToken from URL query if empty
      const sessionTokenInput = document.getElementById('sessionToken');
      if (sessionTokenInput && !sessionTokenInput.value) {
        const urlToken = new URLSearchParams(window.location.search).get('sessionToken');
        if (urlToken) sessionTokenInput.value = urlToken;
      }

      // Wait a moment for ERP jQuery event loop
      await new Promise(r => setTimeout(r, 350));

      // 7. Check if OTP was already requested recently or cooldown is active on page
      const getOtpBtn = document.getElementById('getotp');
      const lastRequested = parseInt(sessionStorage.getItem('erp_otp_requested_time') || '0', 10);
      const isCooldownActive = (lastRequested > 0 && Date.now() - lastRequested < 55000) || (getOtpBtn && getOtpBtn.innerText.includes('Resend ('));

      let baselineId = null;

      if (isCooldownActive) {
        console.log('[ERP Content] OTP was already requested recently. Waiting for incoming code without re-triggering.');
        updateStatus('Waiting for incoming OTP from Gmail...');
      } else {
        // Pre-record baseline message ID before clicking Get OTP
        try {
          const baselineRes = await chrome.runtime.sendMessage({ action: 'RECORD_OTP_BASELINE' });
          if (baselineRes && baselineRes.baselineId) {
            baselineId = baselineRes.baselineId;
          }
        } catch {}

        // Request OTP from ERP
        updateStatus('Requesting OTP from ERP...');
        sessionStorage.setItem('erp_otp_requested_time', Date.now().toString());

        // Reveal OTP input immediately so user can manually type or paste
        if (otpSectionElem) {
          otpSectionElem.style.display = 'block';
          if (otpInputElem) otpInputElem.focus();
        }

        await triggerOtpRequest(creds.rollNumber, password, answer);
      }

      // 8. Show OTP Input & Listener UI
      if (otpSectionElem) {
        otpSectionElem.style.display = 'block';
        if (otpInputElem) otpInputElem.focus();
      }

      startCountdown();
      watchClipboardForOtp();

      // 9. Flag active login state in storage and notify background worker
      chrome.storage.local.set({
        erp_active_login: {
          status: 'waiting_for_otp',
          requestedAt: Date.now(),
          rollNumber: creds.rollNumber
        }
      });

      chrome.runtime.sendMessage({
        action: 'START_OTP_WATCH',
        baselineId: baselineId,
        timestamp: Date.now()
      }).catch(() => {});

    } catch (err) {
      console.error('In-page login error:', err);
      updateStatus(`Error: ${err.message}`, true);
      // Ensure manual OTP input section is visible even on error
      if (otpSectionElem) {
        otpSectionElem.style.display = 'block';
      }
    }
  }

  /**
   * Waits for #question label to receive the security question text
   */
  function waitForSecurityQuestion(rollNumber) {
    return new Promise((resolve, reject) => {
      const getQuestionText = () => {
        const qElem = document.getElementById('question');
        if (qElem && qElem.innerText) {
          const txt = qElem.innerText.trim();
          if (txt.length > 3 && txt.toLowerCase() !== 'security question') {
            return txt;
          }
        }
        const answerDiv = document.getElementById('answer_div');
        if (answerDiv) {
          const label = answerDiv.querySelector('label');
          if (label && label.innerText) {
            const txt = label.innerText.trim();
            if (txt.length > 3 && txt.toLowerCase() !== 'security question') {
              return txt;
            }
          }
        }
        return null;
      };

      const existing = getQuestionText();
      if (existing) return resolve(existing);

      let resolved = false;
      const targetNode = document.getElementById('question') || document.getElementById('answer_div');

      const observer = new MutationObserver(() => {
        const txt = getQuestionText();
        if (txt) {
          resolved = true;
          observer.disconnect();
          resolve(txt);
        }
      });

      if (targetNode) {
        observer.observe(targetNode, { childList: true, subtree: true, characterData: true });
      }

      // Fallback: Query API directly if ERP page didn't populate within 2 seconds
      setTimeout(async () => {
        if (!resolved) {
          try {
            const q = await ErpApi.getSecurityQuestion(rollNumber);
            resolved = true;
            observer.disconnect();
            const qElem = document.getElementById('question');
            if (qElem) qElem.innerText = q;
            resolve(q);
          } catch (err) {
            observer.disconnect();
            reject(err);
          }
        }
      }, 2000);
    });
  }

  /**
   * Triggers the OTP request via native button or fetch
   */
  async function triggerOtpRequest(rollNumber, password, answer) {
    const getOtpBtn = document.getElementById('getotp');
    const emailOtpInput = document.getElementById('email_otp1');
    const submitBtn = document.getElementById('loginFormSubmitButton');

    // Ensure sessionToken is in the form before serialize
    const sessionTokenInput = document.getElementById('sessionToken');
    if (sessionTokenInput && !sessionTokenInput.value) {
      const urlToken = new URLSearchParams(window.location.search).get('sessionToken');
      if (urlToken) sessionTokenInput.value = urlToken;
    }

    // Ensure answer is present so ERP's getEmailOTP serializes it
    const answerInput = document.getElementById('answer');
    if (answerInput && !answerInput.value) {
      answerInput.readOnly = false;
      answerInput.value = answer;
    }

    // 1. If getotp button exists, enable and click it to use ERP's native getEmailOTP('SI')
    if (getOtpBtn) {
      if (!getOtpBtn.innerText.includes('Resend (')) {
        getOtpBtn.disabled = false;
        getOtpBtn.removeAttribute('disabled');
        getOtpBtn.click();
      }

      // Intercept and handle ERP SweetAlert responses intelligently
      const swalCheckInterval = setInterval(async () => {
        const swalElem = document.querySelector('.swal2-container');
        if (!swalElem) return;

        const htmlElem = document.querySelector('.swal2-html-container') || document.querySelector('#swal2-content') || document.querySelector('.swal2-content');
        const titleElem = document.querySelector('.swal2-title');
        const fullText = `${titleElem ? titleElem.innerText : ''} ${htmlElem ? htmlElem.innerText : ''}`.trim().toLowerCase();

        if (fullText) {
          if (fullText.includes('previous session is still active') || fullText.includes('session is active')) {
            clearInterval(swalCheckInterval);
            dismissSweetAlert();
            updateStatus('Previous ERP session was active! Auto-clearing sessions...', false);
            await ErpApi.clearAllSessions(rollNumber);
            updateStatus('Sessions cleared! Retrying OTP request...', false);
            setTimeout(() => triggerOtpRequest(rollNumber, password, answer), 800);
            return;
          }
          if (fullText.includes('answare mismatch') || fullText.includes('answer mismatch')) {
            clearInterval(swalCheckInterval);
            dismissSweetAlert();
            updateStatus('Security Answer Mismatch! Please update your security answers in extension options.', true);
            return;
          }
          if (fullText.includes('password mismatch')) {
            clearInterval(swalCheckInterval);
            dismissSweetAlert();
            updateStatus('ERP Password Mismatch! Please update your password in extension options.', true);
            return;
          }
          if (fullText.includes('an otp') || fullText.includes('sent') || fullText.includes('success')) {
            clearInterval(swalCheckInterval);
            dismissSweetAlert();
            updateStatus('OTP sent to email! Listening to Gmail...');
            return;
          }
        }
      }, 200);

      setTimeout(() => {
        clearInterval(swalCheckInterval);
        dismissSweetAlert();
      }, 4000);

      // Ensure fields become editable immediately
      if (emailOtpInput) {
        emailOtpInput.readOnly = false;
        emailOtpInput.removeAttribute('readonly');
      }
      attachPageOtpListener();
      if (submitBtn) {
        submitBtn.classList.remove('d-none', 'hidden');
        submitBtn.disabled = false;
        submitBtn.removeAttribute('disabled');
      }

      updateStatus('OTP requested! Listening to Gmail...');
      return;
    }

    // 2. Direct API fallback
    const sessionToken = sessionTokenInput ? sessionTokenInput.value : '';
    await ErpApi.requestOTP(rollNumber, password, answer, sessionToken);
    updateStatus('OTP sent to email! Listening to Gmail...');
  }

  /**
   * Dismisses SweetAlert modal if open
   */
  function dismissSweetAlert() {
    try {
      if (window.Swal && typeof window.Swal.close === 'function') {
        window.Swal.close();
      }
    } catch {}

    const swalConfirm = document.querySelector('.swal2-confirm, .swal2-close');
    if (swalConfirm) {
      try { swalConfirm.click(); } catch {}
    }

    document.querySelectorAll('.swal2-container, .swal2-backdrop').forEach((el) => {
      try { el.remove(); } catch {}
    });

    document.body.classList.remove('swal2-shown', 'swal2-height-auto');
    document.body.style.overflow = '';
    document.body.style.paddingRight = '';
  }

  /**
   * Countdown timer for OTP
   */
  function startCountdown() {
    let seconds = 60;
    const countdownElem = document.getElementById('erp-countdown');
    if (countdownTimer) clearInterval(countdownTimer);

    countdownTimer = setInterval(async () => {
      seconds--;
      if (countdownElem) countdownElem.innerText = seconds;

      // Continuously poll shared storage in case background/mail-reader deposited the OTP
      if (!isSubmitting) {
        try {
          const res = await chrome.storage.local.get(['erp_latest_otp']);
          if (res.erp_latest_otp && res.erp_latest_otp.otp) {
            const age = Date.now() - (res.erp_latest_otp.timestamp || 0);
            if (age < 120000) {
              handleOtpFound(res.erp_latest_otp.otp);
            }
          }
        } catch {}
      }

      if (seconds <= 0) {
        clearInterval(countdownTimer);
        sessionStorage.removeItem('erp_otp_requested_time');
        updateStatus('OTP expired or taking too long. Click Resend OTP.');
      }
    }, 1000);
  }

  /**
   * Silently monitors clipboard and window focus for 6-digit OTP copied by the user
   */
  async function watchClipboardForOtp() {
    try {
      const stored = await chrome.storage.local.get(['otpSettings']);
      if (stored.otpSettings && stored.otpSettings.scanClipboard === false) {
        return;
      }
    } catch {}

    let initialClipboard = '';
    try {
      if (document.hasFocus()) {
        initialClipboard = await navigator.clipboard.readText();
      }
    } catch {}

    const checkClipboardNow = async () => {
      if (isSubmitting) return;
      try {
        const text = await navigator.clipboard.readText();
        if (text && text !== initialClipboard) {
          const match = text.match(/\b\d{6}\b/);
          if (match && match[0] !== '721302' && !isSubmitting) {
            handleOtpFound(match[0]);
          }
        }
      } catch {}
    };

    // Instant check as soon as user switches back to this tab
    window.addEventListener('focus', checkClipboardNow);

    const interval = setInterval(async () => {
      if (isSubmitting) {
        clearInterval(interval);
        window.removeEventListener('focus', checkClipboardNow);
        return;
      }
      if (document.hasFocus()) {
        await checkClipboardNow();
      }
    }, 1200);
  }

  /**
   * Submits the OTP into the ERP login form cleanly and reliably
   */
  async function handleOtpFound(otp) {
    const cleanOtp = (otp || '').trim();
    if (!cleanOtp || cleanOtp === '721302' || !/^\d{6}$/.test(cleanOtp)) {
      console.warn('[ERP Content] Ignored invalid OTP candidate:', cleanOtp);
      return;
    }

    if (isSubmitting) return;
    isSubmitting = true;
    if (countdownTimer) clearInterval(countdownTimer);
    sessionStorage.removeItem('erp_otp_requested_time');

    updateStatus('Submitting OTP (••••••)...', false, false);

    // 1. Instantly eliminate SweetAlert
    dismissSweetAlert();

    // 2. Fill into the floating overlay field
    if (otpInputElem) otpInputElem.value = cleanOtp;

    // 3. Fill into all actual ERP form inputs (#email_otp1, input[name="email_otp"])
    const pageOtpInputs = document.querySelectorAll('#email_otp1, input[name="email_otp"], input[id*="email_otp"]');
    pageOtpInputs.forEach((input) => {
      input.readOnly = false;
      input.removeAttribute('readonly');
      input.type = 'password';
      input.value = cleanOtp;
      input.setAttribute('value', cleanOtp);
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      input.dispatchEvent(new Event('blur', { bubbles: true }));
    });

    const form = document.getElementById('loginForm') || document.querySelector('form[action*="auth.htm"]') || document.querySelector('form');
    if (form) {
      // Force explicit absolute SSO endpoint so relative action never targets /IIT_ERP3/auth.htm
      form.action = window.location.origin + '/SSOAdministration/auth.htm';

      // Ensure form has input named email_otp
      let hiddenOtp = form.querySelector('input[name="email_otp"]');
      if (!hiddenOtp) {
        hiddenOtp = document.createElement('input');
        hiddenOtp.type = 'hidden';
        hiddenOtp.name = 'email_otp';
        form.appendChild(hiddenOtp);
      }
      hiddenOtp.value = cleanOtp;

      // Ensure form has typeee='SI'
      let typeeeInput = document.getElementById('typeee') || form.querySelector('input[name="typeee"]');
      if (!typeeeInput) {
        typeeeInput = document.createElement('input');
        typeeeInput.type = 'hidden';
        typeeeInput.name = 'typeee';
        typeeeInput.id = 'typeee';
        form.appendChild(typeeeInput);
      }
      typeeeInput.value = 'SI';

      // Ensure form has requestedUrl
      let reqUrlInput = document.getElementById('requestedUrl') || form.querySelector('input[name="requestedUrl"]');
      if (!reqUrlInput) {
        reqUrlInput = document.createElement('input');
        reqUrlInput.type = 'hidden';
        reqUrlInput.name = 'requestedUrl';
        reqUrlInput.id = 'requestedUrl';
        form.appendChild(reqUrlInput);
      }
      if (!reqUrlInput.value) {
        reqUrlInput.value = window.location.origin + '/IIT_ERP3/';
      }
    }

    // 4. Ensure sessionToken is present in form
    const sessionTokenInput = document.getElementById('sessionToken');
    if (sessionTokenInput && !sessionTokenInput.value) {
      const urlToken = new URLSearchParams(window.location.search).get('sessionToken') || sessionStorage.getItem('erp_session_token');
      if (urlToken) sessionTokenInput.value = urlToken;
    }

    // 5. Ensure core form inputs dispatch change events and keep password hidden
    const userIdInput = document.getElementById('user_id');
    const passwordInput = document.getElementById('password');
    const answerInput = document.getElementById('answer');
    if (userIdInput) userIdInput.dispatchEvent(new Event('change', { bubbles: true }));
    if (passwordInput) {
      passwordInput.type = 'password';
      passwordInput.dispatchEvent(new Event('change', { bubbles: true }));
    }
    if (answerInput) answerInput.dispatchEvent(new Event('change', { bubbles: true }));

    // 6. SUBMISSION: Settle DOM events and trigger clean single submission
    await new Promise(r => setTimeout(r, 120));

    const submitBtn = document.getElementById('loginFormSubmitButton');
    let submitted = false;

    if (submitBtn) {
      submitBtn.classList.remove('d-none', 'hidden');
      submitBtn.removeAttribute('disabled');
      submitBtn.disabled = false;
      try {
        submitBtn.click();
        submitted = true;
      } catch (e) {
        console.warn('[ERP Content] submitBtn.click() error, falling back to form.submit()', e);
      }
    }

    if (!submitted && form) {
      try {
        form.submit();
        submitted = true;
      } catch (e) {
        console.error('[ERP Content] form.submit() error', e);
      }
    }

    // Safe fallback: only if page didn't navigate after 4 seconds and no error shown
    setTimeout(() => {
      const currentUrl = window.location.href;
      if (form && (currentUrl.includes('login.htm') || currentUrl.includes('IIT_ERP3'))) {
        const bodyText = document.body ? document.body.innerText.toLowerCase() : '';
        if (!bodyText.includes('session is active') && !bodyText.includes('previous session')) {
          console.log('[ERP Content] Page did not navigate after 4s; attempting fallback submit...');
          try { form.submit(); } catch {}
        }
      }
    }, 4000);

    // Watch for "previous session is still active" error on page or in modal
    watchForActiveSessionError(currentCreds ? currentCreds.rollNumber : '');
  }

  /**
   * Detects "previous session is still active" and auto-recovers
   */
  function watchForActiveSessionError(rollNumber) {
    let checkCount = 0;
    let handled = false;
    const interval = setInterval(async () => {
      checkCount++;
      if (handled) {
        clearInterval(interval);
        return;
      }
      const pageText = document.body ? document.body.innerText.toLowerCase() : '';
      const swalElem = document.querySelector('.swal2-container, .swal2-html-container, div[role="dialog"]');
      const swalText = swalElem ? swalElem.innerText.toLowerCase() : '';
      const fullText = `${pageText} ${swalText}`;

      const isSessionActive = fullText.includes('previous session is still active') ||
                              fullText.includes('session is active') ||
                              fullText.includes('session is still active') ||
                              fullText.includes('already logged in') ||
                              fullText.includes('active session');

      if (isSessionActive) {
        handled = true;
        clearInterval(interval);
        dismissSweetAlert();
        updateStatus('Previous session was active! Auto-clearing sessions and logging in...', false);
        const roll = rollNumber || (document.getElementById('user_id')?.value) || '';
        if (roll) {
          await ErpApi.clearAllSessions(roll);
          await new Promise(r => setTimeout(r, 400));
          updateStatus('Sessions cleared! Submitting login...', false);
          const submitBtn = document.getElementById('loginFormSubmitButton');
          const form = document.getElementById('loginForm') || document.querySelector('form[action*="auth.htm"]');
          if (submitBtn) {
            submitBtn.classList.remove('d-none', 'hidden');
            submitBtn.removeAttribute('disabled');
            submitBtn.disabled = false;
            submitBtn.click();
          } else if (form) {
            form.submit();
          }
        }
      } else if (checkCount >= 20) {
        clearInterval(interval);
      }
    }, 400);
  }

  // Listen for messages from background or popup
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'USER_LOGGED_OUT') {
      sessionStorage.setItem('erp_just_logged_out', 'true');
      updateStatus('You have logged out of ERP.', false, false);
      showManualLoginButton();
    }
    if (message.action === 'OTP_FOUND' && message.otp) {
      handleOtpFound(message.otp);
    }
  });

  // Listen for storage changes (e.g. toggling Auto-login in Options or Popup, or instant OTP relay)
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local') {
      if (changes.erp_latest_otp && changes.erp_latest_otp.newValue) {
        const item = changes.erp_latest_otp.newValue;
        if (item && item.otp && (Date.now() - (item.timestamp || 0) < 120000)) {
          handleOtpFound(item.otp);
        }
      }

      if (changes.autoLogin !== undefined || changes.authCredentials) {
        chrome.storage.local.get(['authCredentials', 'autoLogin'], (res) => {
          const enabled = res.autoLogin !== undefined ? res.autoLogin : (res.authCredentials && res.authCredentials.autoLogin !== false);
          if (!enabled) {
            updateStatus('Auto-login disabled in General Behavior.', false, false);
            showManualLoginButton();
          }
        });
      }
    }
  });
})();
